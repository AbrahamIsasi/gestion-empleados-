package com.gestion.empleados.repositorios;

import com.gestion.empleados.entidades.Asistencia;
import com.gestion.empleados.entidades.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface AsistenciaRepository extends JpaRepository<Asistencia, Long> {
    // Buscar todas las asistencias de un empleado
    List<Asistencia> findByEmpleado(Empleado empleado);

    // Buscar asistencias de un empleado en un rango de fechas
    List<Asistencia> findByEmpleadoAndFechaBetween(Empleado empleado, Date inicio, Date fin);

    // Buscar todas las asistencias de una fecha específica
    List<Asistencia> findByFecha(Date fecha);
}
