package com.gestion.empleados.security;


import com.gestion.empleados.entidades.Supervisor;
import com.gestion.empleados.repositorios.SupervisorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private SupervisorRepository supervisorRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        Supervisor supervisor = supervisorRepository.findByEmail(email);

        if (supervisor == null) {
            throw new UsernameNotFoundException("No existe el supervisor");
        }

        return new CustomUserDetails(supervisor);
    }
}

