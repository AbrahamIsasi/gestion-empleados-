package com.gestion.empleados.controlador;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Calendar;

import com.gestion.empleados.entidades.EstadoAsistencia;
import com.gestion.empleados.entidades.Supervisor;
import com.gestion.empleados.servicio.SupervisorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.gestion.empleados.entidades.Asistencia;
import com.gestion.empleados.entidades.Empleado;
import com.gestion.empleados.servicio.AsistenciaService;
import com.gestion.empleados.servicio.EmpleadoService;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.security.core.Authentication;


@Controller
@RequestMapping("/asistencias")
public class AsistenciaController {

    @Autowired
    private AsistenciaService asistenciaService;

    @Autowired
    private EmpleadoService empleadoService;

    @Autowired
    private SupervisorService supervisorService;


    /**
     * 📅 Mostrar lista de empleados con su asistencia del día actual o una fecha específica
     */
    @GetMapping
    public String listarAsistencias(
            @RequestParam(name = "fecha", required = false)
            @DateTimeFormat(pattern = "yyyy-MM-dd") Date fecha,
            @RequestParam(name = "sede", required = false) Long sedeSeleccionada,
            @RequestParam(name = "supervisor", required = false) Long supervisorSeleccionado,
            Model modelo,
            Principal principal) {

        if (fecha == null) {
            fecha = new Date();
        }

        String username = principal.getName();
        Long sedeId = null;

        // Si es programador, usa la sede seleccionada
        if ("programador".equals(username)) {
            sedeId = (sedeSeleccionada != null) ? sedeSeleccionada : 1L;
        } else {
            switch (username) {
                case "sjm":
                    sedeId = 1L;
                    break;
                case "sjl":
                    sedeId = 2L;
                    break;
                case "comas":
                    sedeId = 3L;

            }
        }

        // 🔥 Cargar supervisores de esa sede
        List<Supervisor> supervisores = supervisorService.listarPorSede(sedeId);

        // 🔥 FILTRO PRINCIPAL: EMPLEADOS POR SUPERVISOR
        List<Empleado> empleados;

        if (supervisorSeleccionado != null) {
            // ahora usamos el servicio que filtra por supervisor + sede
            empleados = empleadoService.findBySupervisorIdAndSedeId(supervisorSeleccionado, sedeId);
        } else {
            empleados = new ArrayList<>(); // no mostrar empleados si no hay supervisor elegido
        }
        modelo.addAttribute("supervisores", supervisores);
        modelo.addAttribute("supervisorSeleccionado", supervisorSeleccionado);

        modelo.addAttribute("empleados", empleados);
        modelo.addAttribute("asistencias", asistenciaService.findByFecha(fecha));
        modelo.addAttribute("fechaSeleccionada", fecha);
        modelo.addAttribute("sedeSeleccionada", sedeId);
        modelo.addAttribute("titulo", "Control de Asistencias - " + fecha);

        return "asistencias";
    }


    /**
     * 📝 Registrar o actualizar la asistencia de un empleado
     */
    @PostMapping("/registrar")
    public String registrarAsistencia(
            @RequestParam("empleadoId") Long empleadoId,
            @RequestParam("fecha") @DateTimeFormat(pattern = "yyyy-MM-dd") Date fecha,
            @RequestParam("estado") String estado,
            @RequestParam(name = "supervisor", required = false) Long supervisorId,
            @RequestParam(name = "sede", required = false) Long sedeId) {

        // ... tu lógica de guardado ...

        String fechaStr = new java.text.SimpleDateFormat("yyyy-MM-dd").format(fecha);

        String redirect = "redirect:/asistencias?fecha=" + fechaStr;
        if (supervisorId != null) redirect += "&supervisor=" + supervisorId;
        if (sedeId != null) redirect += "&sede=" + sedeId;

        return redirect;
    }

    @PostMapping("/guardar")
    public String guardarAsistencias(
            @RequestParam Map<String, String> params,
            @RequestParam("fecha") @DateTimeFormat(pattern = "yyyy-MM-dd") Date fecha,
            @RequestParam(name = "sedeId", required = false) Long sedeId,
            @RequestParam(name = "registradoPor", required = false) Long supervisorId,
            RedirectAttributes redirectAttributes,
            Authentication authentication) {

        // Validación fecha
        Calendar hoy = Calendar.getInstance();
        Calendar fechaSeleccionada = Calendar.getInstance();
        fechaSeleccionada.setTime(fecha);

        boolean mismaFecha =
                hoy.get(Calendar.YEAR) == fechaSeleccionada.get(Calendar.YEAR) &&
                        hoy.get(Calendar.MONTH) == fechaSeleccionada.get(Calendar.MONTH) &&
                        hoy.get(Calendar.DAY_OF_MONTH) == fechaSeleccionada.get(Calendar.DAY_OF_MONTH);

        if (!mismaFecha) {
            redirectAttributes.addFlashAttribute("error", "Solo se permite registrar asistencias del día actual.");
            return "redirect:/asistencias";
        }

        // 🔥 Supervisor que REGISTRA la asistencia
        Supervisor supervisor = null;
        if (supervisorId != null) {
            supervisor = supervisorService.findById(supervisorId);
        }

        // Procesar asistencias
        for (String key : params.keySet()) {
            if (key.startsWith("estado_")) {
                Long empleadoId = Long.parseLong(key.replace("estado_", ""));
                String estadoStr = params.get(key);

                if (estadoStr == null || estadoStr.isEmpty()) continue;

                Empleado empleado = empleadoService.obtenerPorId(empleadoId);
                if (empleado == null) continue;

                Asistencia asistencia = new Asistencia();
                asistencia.setEmpleado(empleado);
                asistencia.setFecha(fecha);
                asistencia.setEstadoAsistencia(EstadoAsistencia.valueOf(estadoStr));

                // 🔥 Guardar quién registró la asistencia
                asistencia.setRegistradoPor(supervisor);

                asistenciaService.save(asistencia);
            }
        }

        redirectAttributes.addFlashAttribute("exito", "Asistencias registradas correctamente.");

        // Redirecciones
        String username = authentication.getName();
        if (username.equals("programador") && sedeId != null) {
            return "redirect:/listar?sede=" + sedeId;
        }

        return "redirect:/listar";
    }



}
