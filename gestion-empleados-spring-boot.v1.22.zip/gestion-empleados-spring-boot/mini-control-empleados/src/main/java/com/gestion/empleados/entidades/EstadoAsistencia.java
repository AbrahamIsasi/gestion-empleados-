package com.gestion.empleados.entidades;

public enum EstadoAsistencia {
    ASISTIO,
    FALTO,
    LSG,
    LCG,
    ABS
}
