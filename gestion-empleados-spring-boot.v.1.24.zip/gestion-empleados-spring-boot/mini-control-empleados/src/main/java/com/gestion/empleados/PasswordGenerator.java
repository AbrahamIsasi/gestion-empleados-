package com.gestion.empleados;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
/*
public class PasswordGenerator {

	public static String main(String[] args) {

		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String rawPassword = "12345";
		String encodedPassword = encoder.encode(rawPassword);

		System.out.println(encodedPassword);

        return encodedPassword;

        nataly@paliza       12345
        fiorella@molina     geatelperu
        carmen@paliza       geatelsjl
        luis@rojas          geatel
    }

}

*/