package com.gestion.empleados.controlador;

import java.io.IOException;
import java.security.Principal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import com.gestion.empleados.entidades.Sede;
import com.gestion.empleados.entidades.Supervisor;
import com.gestion.empleados.servicio.SedeService;
import com.gestion.empleados.servicio.SupervisorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.gestion.empleados.entidades.Empleado;
import com.gestion.empleados.servicio.EmpleadoService;
import com.gestion.empleados.util.paginacion.PageRender;
import com.gestion.empleados.util.reportes.EmpleadoExporterExcel;
import com.gestion.empleados.util.reportes.EmpleadoExporterPDF;
import com.lowagie.text.DocumentException;
import org.springframework.security.core.Authentication;


@Controller
public class EmpleadoController {

	@Autowired
	private EmpleadoService empleadoService;

	@Autowired
	private SedeService sedeService;

    @Autowired
    private SupervisorService supervisorService;


	// Método para obtener el ID de sede según el usuario logeado
	private Long obtenerSedeIdPorUsuario(String username) {
		switch (username) {
			case "sjm":
				return 1L;
			case "sjl":
				return 2L;
            case "comas":
                return 3L;
			case "programador":
				return 1L;
            default:
                return null;
		}
	}

	// === VER DETALLES DE EMPLEADO ===
	@GetMapping("/ver/{id}")
	public String verDetallesDelEmpleado(@PathVariable(value = "id") Long id,
										 Map<String, Object> modelo,
										 RedirectAttributes flash) {
		Empleado empleado = empleadoService.findOne(id);
		if (empleado == null) {
			flash.addFlashAttribute("error", "El empleado no existe en la base de datos");
			return "redirect:/listar";
		}

		modelo.put("empleado", empleado);
		modelo.put("titulo", "Detalles del empleado " + empleado.getNombreCompleto());
		return "ver";
	}


	// === LISTAR EMPLEADOS POR SEDE ===
    @GetMapping({"/", "/listar", ""})
    public String listarEmpleados(
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "sede", required = false) Long sedeIdParam,
            @RequestParam(name = "supervisor", required = false) Long supervisorId,
            Model modelo,
            Principal principal) {

        if (principal == null) {
            modelo.addAttribute("error", "No hay un usuario autenticado");
            return "redirect:/login";
        }

        String username = principal.getName();
        Pageable pageRequest = PageRequest.of(page, 50);
        Page<Empleado> empleados;

    /* =======================================================================================
       CASO 1: USUARIO PROGRAMADOR (puede elegir cualquier sede)
       ======================================================================================= */
        if (username.equals("programador")) {

            Long sedeId = (sedeIdParam != null) ? sedeIdParam : 1L;

            empleados = empleadoService.findBySedeId(sedeId, pageRequest);

            modelo.addAttribute("sedes", sedeService.findAll());
            modelo.addAttribute("sedeSeleccionada", sedeId);
            modelo.addAttribute("titulo", "Listado general de empleados");

        } else {

        /* =======================================================================================
           CASO 2: CUALQUIER OTRO USUARIO → sede fija según login
           ======================================================================================= */
            Long sedeId = obtenerSedeIdPorUsuario(username);

            if (sedeId == null) {
                modelo.addAttribute("error", "No se pudo determinar la sede del usuario");
                return "error";
            }

        /* =======================================================================================
           FILTRO OPCIONAL POR SUPERVISOR
           ======================================================================================= */
            if (supervisorId != null && supervisorId > 0) {
                List<Empleado> lista = empleadoService.findBySupervisorAndSede(supervisorId, sedeId);

                // Convertimos la lista a Page
                Page<Empleado> pagina = new PageImpl<>(lista, pageRequest, lista.size());
                empleados = pagina;

                modelo.addAttribute("supervisorSeleccionado", supervisorId);

            } else {
                empleados = empleadoService.findBySedeId(sedeId, pageRequest);
            }

            // Carga de supervisores para el combo box
           // modelo.addAttribute("supervisores", empleadoService.findSupervisoresPorSede(sedeId));
            modelo.addAttribute("supervisores", supervisorService.listarPorSede(sedeId));


            modelo.addAttribute("titulo", "Listado de empleados - " + username.toUpperCase());
        }

        PageRender<Empleado> pageRender = new PageRender<>("/listar", empleados);

        modelo.addAttribute("empleados", empleados);
        modelo.addAttribute("page", pageRender);

        return "listar";
    }

    // -------------------- FORMULARIO --------------------
    @GetMapping("/form")
    public String mostrarFormulario(
            @RequestParam(value = "supervisor", required = false) Long idSupervisor,
            @RequestParam(value = "sede", required = false) Long sedeIdParam,
            Model modelo,
            Principal principal) {

        String username = principal.getName();
        Long sedeId;

        // 🔥 REGLA:
        // 1. Si se envía "sede" por URL → usar ese valor
        // 2. Si NO se envía → usar la sede del usuario
        if (sedeIdParam != null) {
            sedeId = sedeIdParam;
        } else {
            sedeId = obtenerSedeIdPorUsuario(username);
        }

        // LOG para depuración
        System.out.println("[FORM] supervisor=" + idSupervisor + ", sede=" + sedeId);

        // Crear empleado
        Empleado empleado = new Empleado();

        // 🔥 Traer supervisores SOLO de esa sede
        List<Supervisor> supervisores = supervisorService.listarPorSede(sedeId);

        // Si viene un supervisor seleccionado → seleccionarlo en el form
        if (idSupervisor != null && idSupervisor > 0) {
            Supervisor sup = supervisores.stream()
                    .filter(s -> s.getIdSupervisor().equals(idSupervisor))
                    .findFirst()
                    .orElse(null);

            if (sup != null) {
                empleado.setSupervisor(sup);
            }
        }

        // Enviar datos al modelo
        modelo.addAttribute("empleado", empleado);
        modelo.addAttribute("supervisores", supervisores);
        modelo.addAttribute("sedeSeleccionada", sedeId);
        modelo.addAttribute("titulo", "Registro de empleados");

        // Mostrar combo de sedes SOLO para programador
        if ("programador".equals(username)) {
            modelo.addAttribute("sedes", sedeService.findAll());
        }

        return "form";
    }

    // ----------------------- GUARDAR -----------------------
    @PostMapping("/form")
    public String guardarEmpleado(
            @Valid @ModelAttribute("empleado") Empleado empleado,
            BindingResult result,
            @RequestParam("sede") Long sedeId,   // ← ahora sí
            Model modelo,
            RedirectAttributes flash,
            SessionStatus status,
            Authentication authentication) {

        if (result.hasErrors()) {
            modelo.addAttribute("titulo", "Registro de empleados");

            // Volver a cargar supervisores según sede
            modelo.addAttribute("supervisores", supervisorService.listarPorSede(sedeId));
            return "form";
        }

        /* SUPERVISOR */
        if (empleado.getSupervisor().getIdSupervisor() != null) {
            Supervisor sup = supervisorService.obtenerPorId(empleado.getSupervisor().getIdSupervisor());
            empleado.setSupervisor(sup);
        }

        /* SEDE CORRECTA SEGÚN FORMULARIO (NO SEGÚN USUARIO) */
        Sede sede = sedeService.findById(sedeId)
                .orElseThrow(() -> new RuntimeException("No se encontro la sede"));

        empleado.setSede(sede);

        empleadoService.save(empleado);
        status.setComplete();

        flash.addFlashAttribute("success", "Empleado guardado correctamente");

        return "redirect:/listar?sede=" + sedeId + "&supervisor=" + empleado.getSupervisor().getIdSupervisor();
    }




    // === EDITAR EMPLEADO ===
    @GetMapping("/form/{id}")
    public String editarEmpleado(
            @PathVariable(value = "id") Long id,
            Map<String, Object> modelo,
            RedirectAttributes flash,
            Authentication authentication) {

        Empleado empleado = null;

        if (id > 0) {
            empleado = empleadoService.findOne(id);
            if (empleado == null) {
                flash.addFlashAttribute("error", "El ID del empleado no existe en la base de datos");
                return "redirect:/listar";
            }
        } else {
            flash.addFlashAttribute("error", "El ID del empleado no puede ser cero");
            return "redirect:/listar";
        }

        modelo.put("empleado", empleado);
        modelo.put("titulo", "Edición de empleado");

        // 🔹 Obtener la sede del usuario
        String username = authentication.getName();
        Long sedeId = obtenerSedeIdPorUsuario(username);

        // 🔹 Cargar supervisores
        List<Supervisor> supervisores = supervisorService.listarPorSede(sedeId);
        modelo.put("supervisores", supervisores);

        // 🔹 Solo programador ve sedes
        if ("programador".equals(username)) {
            modelo.put("sedes", sedeService.findAll());
        }

        return "form";
    }


    // === ELIMINAR EMPLEADO ===
	@GetMapping("/eliminar/{id}")
	public String eliminarCliente(@PathVariable(value = "id") Long id,
								  RedirectAttributes flash) {
		if (id > 0) {
			empleadoService.delete(id);
			flash.addFlashAttribute("success", "Empleado eliminado con éxito");
		}
		return "redirect:/listar";
	}

	@GetMapping("/exportarPDF")
	public void exportarListadoDeEmpleadosEnPDF(HttpServletResponse response) throws DocumentException, IOException {
		response.setContentType("application/pdf");

		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String fechaActual = dateFormatter.format(new Date());

		String cabecera = "Content-Disposition";
		String valor = "attachment; filename=Empleados_" + fechaActual + ".pdf";

		response.setHeader(cabecera, valor);

		List<Empleado> empleados = empleadoService.findAll();

		EmpleadoExporterPDF exporter = new EmpleadoExporterPDF(empleados);
		exporter.exportar(response);
	}

	@GetMapping("/exportarExcel")
	public void exportarListadoDeEmpleadosEnExcel(HttpServletResponse response) throws DocumentException, IOException {
		response.setContentType("application/octet-stream");

		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String fechaActual = dateFormatter.format(new Date());

		String cabecera = "Content-Disposition";
		String valor = "attachment; filename=Empleados_" + fechaActual + ".xlsx";

		response.setHeader(cabecera, valor);

		List<Empleado> empleados = empleadoService.findAll();

		EmpleadoExporterExcel exporter = new EmpleadoExporterExcel(empleados);
		exporter.exportar(response);
	}
}
